from typing import Any, Dict, List, Optional
from pydantic import BaseModel


class SolveRequest(BaseModel):
    term_id: Optional[int] = None


class AllocationInput(BaseModel):
    term_id: int
    section_id: int
    requirement_id: int
    instructor_id: int
    room_id: int
    weekday: int
    starts_at: str
    ends_at: str
    session_date: Optional[str] = None


class ValidationResponse(BaseModel):
    primary_result: str
    reasons: List[str]
    slot_id: Optional[int] = None


class ChangeRequest(BaseModel):
    allocation_id: int
    session_date: str

    proposed_room_id: Optional[int] = None
    proposed_instructor_id: Optional[int] = None
    proposed_start_slot_id: Optional[int] = None


class ChangeValidationResponse(BaseModel):
    status: str
    primary_result: Optional[str] = None
    reasons: List[str]

    source_published_version_id: Optional[int] = None
    source_allocation_id: Optional[int] = None
    proposal: Optional[Dict[str, Any]] = None