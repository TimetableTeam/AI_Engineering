from fastapi import FastAPI, HTTPException

from .models import (
    SolveRequest,
    AllocationInput,
    ValidationResponse,
    ChangeRequest,
    ChangeValidationResponse,
)

from .service import load_solver_output
from .engine import (
    check_allocation,
    evaluate_published_change_request,
)
from .solver import solve_schedule
app = FastAPI(
    title="Tanseek Scheduling AI Service",
    description=(
        "Constraint-based timetable, room and lab "
        "allocation service for Tanseek."
    ),
    version="1.0.0"
)


# =================================================
# Root
# =================================================

@app.get("/")
def root():
    return {
        "service": "Tanseek Scheduling AI Service",
        "status": "running",
        "version": "1.0.0"
    }


# =================================================
# Health Check
# =================================================

@app.get("/health")
def health():
    return {
        "status": "ok",
        "service": "tanseek-ai"
    }


# =================================================
# Solver Result
# =================================================

@app.post("/solve")
def solve(request: SolveRequest):

    try:
        result = load_solver_output()

    except FileNotFoundError as error:
        raise HTTPException(
            status_code=503,
            detail=str(error)
        )

    if request.term_id is not None:

        output_term_id = (
            result
            .get("version_context", {})
            .get("term_id")
        )

        if (
            output_term_id is not None
            and int(output_term_id)
            != int(request.term_id)
        ):
            raise HTTPException(
                status_code=400,
                detail=(
                    "The generated solver output "
                    "belongs to another term."
                )
            )

    return result


# =================================================
# Solver Summary
# =================================================

@app.get("/solver/summary")
def solver_summary():

    try:
        result = load_solver_output()

    except FileNotFoundError as error:
        raise HTTPException(
            status_code=503,
            detail=str(error)
        )

    return {
        "solver_status":
            result.get("solver_status"),

        "version_context":
            result.get("version_context"),

        "summary":
            result.get("summary"),

        "objective_breakdown":
            result.get("objective_breakdown"),

        "date_specific_constraints":
            result.get(
                "date_specific_constraints"
            )
    }


# =================================================
# Scheduled Sessions
# =================================================

@app.get("/solver/scheduled")
def scheduled_sessions():

    try:
        result = load_solver_output()

    except FileNotFoundError as error:
        raise HTTPException(
            status_code=503,
            detail=str(error)
        )

    return {
        "count":
            len(
                result.get(
                    "scheduled_sessions",
                    []
                )
            ),

        "sessions":
            result.get(
                "scheduled_sessions",
                []
            )
    }


# =================================================
# Unscheduled Sessions
# =================================================

@app.get("/solver/unscheduled")
def unscheduled_sessions():

    try:
        result = load_solver_output()

    except FileNotFoundError as error:
        raise HTTPException(
            status_code=503,
            detail=str(error)
        )

    return {
        "count":
            len(
                result.get(
                    "unscheduled_sessions",
                    []
                )
            ),

        "sessions":
            result.get(
                "unscheduled_sessions",
                []
            )
    }


# =================================================
# Validate Allocation
# =================================================

@app.post(
    "/validate-allocation",
    response_model=ValidationResponse
)
def validate_allocation(
    request: AllocationInput
):

    try:

        result = check_allocation(
            term_id=
                request.term_id,

            section_id=
                request.section_id,

            requirement_id=
                request.requirement_id,

            instructor_id=
                request.instructor_id,

            room_id=
                request.room_id,

            weekday=
                request.weekday,

            starts_at=
                request.starts_at,

            ends_at=
                request.ends_at,

            session_date=
                request.session_date
        )

        return result

    except Exception as error:

        raise HTTPException(
            status_code=500,
            detail=str(error)
        )
# =================================================
# Validate Published Change Request
# =================================================

@app.post(
    "/validate-change",
    response_model=ChangeValidationResponse
)
def validate_change(
    request: ChangeRequest
):

    try:

        result = (
            evaluate_published_change_request(
                allocation_id=
                    request.allocation_id,

                session_date=
                    request.session_date,

                proposed_room_id=
                    request.proposed_room_id,

                proposed_instructor_id=
                    request.proposed_instructor_id,

                proposed_start_slot_id=
                    request.proposed_start_slot_id
            )
        )

        return result

    except Exception as error:

        raise HTTPException(
            status_code=500,
            detail=str(error)
        )        